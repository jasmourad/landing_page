# Udacity FE Developer - Project no.2

## Scope & Features
Create a landing page based on content provided in the page. 

Multi-section landing page featuring a dynamic menu as well as a smooth scroll effect.

## Prereq's & getting started
1. Starter code available
2. Download project (https://github.com/udacity/fend/tree/refresh-2019) 
3. Clone branch  'refresh 2019'

## Credits 
Martin Tavernier(https://stackoverflow.com/users/12159514/martin-tavernier) for quick response and help around scroll function issue.






